import Vue from 'vue'
import Person from './person'

const app = new Vue(Person)
app.$mount()
